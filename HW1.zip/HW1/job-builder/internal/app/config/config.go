package config

type ServerInfo struct {
	IP   string `yaml:"ip"`
	Port string `yaml:"port"`
}

type RabbitMQInfo struct {
	
}
