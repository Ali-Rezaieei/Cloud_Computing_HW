package api


// TODO: use s3 sdk to upload object into arvan cloud!
func ArvanCloudS3() {
	
}